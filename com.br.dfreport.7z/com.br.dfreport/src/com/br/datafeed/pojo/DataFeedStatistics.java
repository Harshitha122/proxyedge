package com.br.datafeed.pojo;

import java.sql.Timestamp;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.br.datafeed.util.DateAdapter;
import com.br.datafeed.util.TimeAdapter;


@XmlAccessorType(XmlAccessType.FIELD)
public class DataFeedStatistics {
	
	private int jobId;
	@XmlJavaTypeAdapter(DateAdapter.class)
	private Date runDate;
	private int runNumber;
	private int totalRecords;
	private int totalErrors;
	private int totalInserts;
	private int totalUpdates;
	private int totalWarnings;
	private int totalRejects;
	private String color;
	private String jobType;
	private String jobName;
	private String status;
	@XmlJavaTypeAdapter(TimeAdapter.class)
	private Timestamp startDate;
	@XmlJavaTypeAdapter(TimeAdapter.class)
	private Timestamp endDate;
	
	private int cppJobRunNbr;
	
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public Date getRunDate() {
		return runDate;
	}
	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	public int getRunNumber() {
		return runNumber;
	}
	public void setRunNumber(int runNumber) {
		this.runNumber = runNumber;
	}
	public int getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	public int getTotalErrors() {
		return totalErrors;
	}
	public void setTotalErrors(int totalErrors) {
		this.totalErrors = totalErrors;
	}
	public int getTotalInserts() {
		return totalInserts;
	}
	public void setTotalInserts(int totalInserts) {
		this.totalInserts = totalInserts;
	}
	public int getTotalUpdates() {
		return totalUpdates;
	}
	public void setTotalUpdates(int totalUpdates) {
		this.totalUpdates = totalUpdates;
	}
	public int getTotalWarnings() {
		return totalWarnings;
	}
	public void setTotalWarnings(int totalWarnings) {
		this.totalWarnings = totalWarnings;
	}
	public int getTotalRejects() {
		return totalRejects;
	}
	public void setTotalRejects(int totalRejects) {
		this.totalRejects = totalRejects;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getStartDate() {
		return startDate;
	}
	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}
	public Timestamp getEndDate() {
		return endDate;
	}
	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}
	public int getCppJobRunNbr() {
		return cppJobRunNbr;
	}
	public void setCppJobRunNbr(int cppJobRunNbr) {
		this.cppJobRunNbr = cppJobRunNbr;
	}

}
