package com.br.datafeed.wrapper;

import java.io.File;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.StringTokenizer;

import javax.mail.internet.AddressException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import com.adp.core.exception.ADPFatalException;
import com.adp.core.exception.ADPWarningException;
import com.adp.core.exception.MailSendException;
import com.br.batch.util.logger.BRLoggerFactory;
import com.br.batch.util.logger.IBRLogger;
import com.br.batch.util.property.PropertyMgr;
import com.br.datafeed.batch.BatchProcessor;
import com.br.datafeed.dao.DataFeedReportDAO;
import com.br.datafeed.pojo.DataFeedErrors;
import com.br.datafeed.pojo.DataFeedInstitutions;
import com.br.datafeed.pojo.DataFeedStatistics;
import com.br.datafeed.util.DataFeedReportConstants;
import com.br.datafeed.util.EmailContent;
import com.br.datafeed.util.EmailManager;


public class DataFeedDailyBatch implements BatchProcessor {

	private static IBRLogger logger	= BRLoggerFactory.getLogger(DataFeedDailyBatch.class);
	
	EmailContent emailContent = new EmailContent();
	EmailManager emailManager;
	ArrayList<String> alEmailRecipients=null;
	ArrayList<String> attachmentFiles=null;
	DataFeedReportDAO dataFeedReportDAO;
	String [] saAttachments=null;
	
	String reportName = null; //used to distinguish PD, CPP reports. For PE this would be null
	boolean hasErrors = false; //this flag is used to set high priority to the email generated for PD and CPP
	int maxErrorCnt; //maximum number of errors that will shown in the generated reports for PD and CPP
	
	@Override
	public void executeBatch() throws ADPWarningException,ADPFatalException{
			
		logger.info("executeBatch(): ENTER");
     	try {     	    		    		
     		//PropertyMgr.getInstance().appendPropertiesAsResource("com/br/datafeed/properties/DataFeedReport.properties");
     		
     		reportName = PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.REPORT_NAME);
     		logger.info("Report generating for: "+reportName);
     		
     		DataFeedDailyBatch dfDailyBatch = new DataFeedDailyBatch();
     		dfDailyBatch.getDataFeedReportDetails(reportName);
     		if(reportName == null){
     			attachmentFiles=dfDailyBatch.getEmailAttachments();
     			if(attachmentFiles!=null && !attachmentFiles.isEmpty())
     				dfDailyBatch.sendEmail(attachmentFiles,reportName);
     			else
     				logger.info("No attachement found");
     		}else{
     			dfDailyBatch.sendEmail(attachmentFiles,reportName);
     		}
     		
     	} catch(ADPFatalException af){
     		logger.info("ERROR:Exception " + af.getMessage());
     		throw new ADPFatalException(af.getMessage());
     	}catch(MailSendException mx){
     		logger.info("ERROR:Exception " + mx.getMessage());
     		throw new ADPFatalException(mx.getMessage());
     	} catch(Exception e) {
     	  	logger.info("ERROR:Exception " + e.getMessage());
     		throw new ADPWarningException(e.getMessage());
     		
		}
		logger.info("executeBatch(): EXIT");
	}
	
	private void getDataFeedReportDetails(String reportName) throws ADPFatalException {
		logger.info("getDataFeedReportDetails(): ENTER");		
		try{		
		// Declare method variables
			dataFeedReportDAO = new DataFeedReportDAO(reportName);
			List<DataFeedStatistics> listDFStatistics = new ArrayList<DataFeedStatistics>();
			List<DataFeedErrors>  listDFErrors= new ArrayList<DataFeedErrors>();
			List<DataFeedInstitutions> listDFInst = new ArrayList<DataFeedInstitutions>();
			List<DataFeedInstitutions> listDFFirstActivity= new ArrayList<DataFeedInstitutions>();
			maxErrorCnt = DataFeedReportConstants.MAX_ERROR_CNT_PD_CPP;
			try {
				if(reportName == null){
					listDFStatistics=dataFeedReportDAO.generateDFProcessingReport();
					listDFErrors=dataFeedReportDAO.generateErrorReport();
					listDFInst=dataFeedReportDAO.generateInstitutionReport();
					listDFFirstActivity=dataFeedReportDAO.generateFirstActivityReport();
				}else if(reportName.equalsIgnoreCase(DataFeedReportConstants.PD_REPORT)){
					listDFStatistics=dataFeedReportDAO.generateDFProcessingReport();
					listDFErrors=dataFeedReportDAO.generatePDErrorReport();
					if ( null != PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS) &&
							PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS).length() >0)
					{
						maxErrorCnt = Integer.parseInt(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS));
					}
				}else if(reportName.equalsIgnoreCase(DataFeedReportConstants.CPP_REPORT)){
					listDFStatistics=dataFeedReportDAO.generateCPPDFProcessingReport();
					listDFErrors=dataFeedReportDAO.generateCPPErrorReport();
					if ( null != PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS) &&
							PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS).length() >0)
					{
						maxErrorCnt = Integer.parseInt(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS));
					}
				}
				
				
			} catch (SQLException e) {
				logger.info("SQLException occurred while getting JOB Run statistics"+e.getMessage());
				throw e;	
			}catch (Exception ex){
				logger.info("Exception occurred while getting JOB Run statistics"+ex.getMessage());
				throw ex;
			}
			
			if(reportName != null){
				logger.debug("Report generated for : "+reportName);
				emailContent.setReportName(reportName);
			}
			
			if ( listDFStatistics != null && !listDFStatistics.isEmpty()) {
				logger.debug("Statistics Records Found : "+listDFStatistics.size() );
				emailContent.setDfStatisticsList(listDFStatistics);
				emailContent.setCppJobRunNbr(listDFStatistics.get(0).getCppJobRunNbr());
				logger.debug("CPP job number :"+emailContent.getCppJobRunNbr());
			}
			
			if ( listDFErrors!=null && !listDFErrors.isEmpty() ) {
				logger.debug("Error Records Found : "+listDFErrors.size());
				emailContent.setDfErrorsList(listDFErrors);
				emailContent.setMaxErrorCnt(maxErrorCnt);
				hasErrors = true;
			}
			
			if ( listDFInst!=null && !listDFInst.isEmpty()){
				emailContent.setDfInstitutionList(listDFInst);
			}
			
			if ( listDFFirstActivity!=null && !listDFFirstActivity.isEmpty())
				emailContent.setDfInstFirstActivity(listDFFirstActivity);
	
	
			logger.info("getDataFeedReportDetails(): EXIT");
		}catch (SQLException e) {
			logger.info("SQLException occurred while getting JOB Run statistics"+e.getMessage());
			throw new ADPFatalException(e.getMessage());	
		}catch (Exception ex){
			logger.info("Exception occurred while getting JOB Run statistics"+ex.getMessage());
			throw new ADPFatalException(ex.getMessage());
		}
	}
	
	private ArrayList<String> getEmailAttachments() throws ADPFatalException {
		logger.info("getEmailAttachments(): ENTER");
		ArrayList<String> alAttachments=new ArrayList<String>();
		StringBuffer sbJobList=null;
		String sLogfile=null;
		File strLogFileExists=null;
		try{
			String sExcelFile =dataFeedReportDAO.generateXLSDFProcessingReport(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.TEMP_DIRECTORY));
			if(sExcelFile!=null && sExcelFile.trim().length()>0){
				logger.info("Generated DateFeed Excel file added to email attachment");
				alAttachments.add(sExcelFile);
			}
			if(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.ATTACH_LOGFILES)!=null && PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.ATTACH_LOGFILES).equalsIgnoreCase("Y")){
				if(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.JOB_LIST)!=null && PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.JOB_LIST).equalsIgnoreCase("ALL")){
					sbJobList=dataFeedReportDAO.getJobIDS();
					StringTokenizer stn = new StringTokenizer(sbJobList+"",",");
						Calendar cal = Calendar.getInstance();
						String day = null;
						switch (cal.get(Calendar.DAY_OF_WEEK)) {
						case 1:
							day = "Sun";
							break;					
						case 2:
							day = "Mon";
							break;
						case 3:
							day = "Tue";
							break;
						case 4:
							day = "Wed";
							break;
						case 5:
							day = "Thu";
							break;
						case 6:
							day = "Fri";
							break;
						case 7:
							day = "Sat";
							break;
						default:
							day = null;
						}
						while (stn.hasMoreTokens()) {
							String strJobIDS = (String) stn.nextToken();
							sLogfile = PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.LOG_FILES_DIRECTORY) + PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.LOG_FILE_PREFIX);
							if (day != null) {
								sLogfile.concat("." + day + "." + "log");
							}
							if (strJobIDS != null) {
								sLogfile.concat("_" + strJobIDS + "." + "log");
							}
							if ((strJobIDS != null) && (day != null)) {
								sLogfile.concat("_" + strJobIDS + "." + day + "." + "log");
							}
							strLogFileExists = new File(sLogfile);
							if (!(strJobIDS.equalsIgnoreCase("2270"))) {
								if (strLogFileExists.exists()) {
									alAttachments.add(sLogfile);
								} 
							}
						}
	
					}
				
				}
		}catch(MailSendException ml){
			logger.error("MailSendException in DataFeedDailyBatch:getEmailAttachments()");
			throw new ADPFatalException(ml.getMessage());
		}catch(Exception e){
			logger.error("Exception in DataFeedDailyBatch:getEmailAttachments()");
			throw new ADPFatalException(e.getMessage());
		}
		logger.info(" getEmailAttachments():EXIT");	
		return alAttachments;
	}
	
	
	private void sendEmail(ArrayList<String> alAttachments,String reportName) throws MailSendException {
		logger.info(" sendEmail():ENTER");		
        StringWriter writer = new StringWriter();
        StringWriter htmlWriter = new StringWriter();        
        JAXBContext context = null;
        Marshaller marshaller = null;
        Reader reader = null;
        File xsltFile = null;
        Source xmlSource = null;
        Source xsltSource = null;
        String errorMsg = null;
        try {
				context = JAXBContext.newInstance(EmailContent.class);       
				marshaller = context.createMarshaller();
				marshaller.marshal(emailContent, writer);
				reader = new StringReader(writer.toString());
			    xsltFile = new File(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.DATAFEED_EMAIL_XSLT_FILE));	    
			    if ( xsltFile.exists() ) {
				    xmlSource = new StreamSource(reader);
				    xsltSource = new StreamSource(xsltFile);
			        TransformerFactory transFact = TransformerFactory.newInstance();
			        Transformer trans = transFact.newTransformer(xsltSource);
			        trans.transform(xmlSource, new StreamResult(htmlWriter));	  
			    } else{
			    	errorMsg = "ERROR: Cannot find xslt file " + PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.DATAFEED_EMAIL_XSLT_FILE);
			    	logger.error(errorMsg);
			    }
		        String emailRecipient = PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.EMAIL_TO_ADDRESS);
		        if(emailRecipient != null && !"".equals(emailRecipient)){
		        	alEmailRecipients = new ArrayList<String>(Arrays.asList(emailRecipient.split(",")));
		        }else {
			        dataFeedReportDAO = new DataFeedReportDAO(reportName);
			        alEmailRecipients=dataFeedReportDAO.getAllEmailRecipients(reportName);
		        }
		        logger.debug("Email Recipients count: "+alEmailRecipients.size());
		        emailManager = new EmailManager(alEmailRecipients);
		        logger.debug("Sending email");
		        if(reportName==null){
		        	emailManager.sendMailwithAttachment(htmlWriter.toString(),alAttachments,false);
		        }else{
		        	emailManager.sendMailwithAttachment(htmlWriter.toString(),alAttachments,hasErrors);
		        }
		} catch(AddressException ae){
			logger.debug("AddressException " + ae.getMessage());
			errorMsg = ae.getMessage();
			throw new MailSendException(ae.getMessage());
		}catch (JAXBException jbe) {			
		
			logger.debug("JAXBException " + jbe.getMessage());
			errorMsg = jbe.getMessage();
			throw new MailSendException(jbe.getMessage());
		} catch (TransformerFactoryConfigurationError tce) {
			logger.debug("TransformerConfigurationException " + tce.getMessage());
			errorMsg = tce.getMessage();
			throw new MailSendException(tce.getMessage());
		}catch (TransformerConfigurationException tce) {
			logger.debug("TransformerConfigurationException " + tce.getMessage());
			errorMsg = tce.getMessage();
			throw new MailSendException(tce.getMessage());
		} catch (TransformerException te) {
			logger.debug("TransformerException " + te.getMessage());
			errorMsg = te.getMessage();
			throw new MailSendException(te.getMessage());
		} catch(SQLException sq){
			logger.debug("SQLException " + sq.getMessage());
			throw new MailSendException(sq.getMessage());
		}catch(MailSendException mx){
			logger.debug("MailSendException " + mx.getMessage());
			throw new MailSendException(mx.getMessage());
		}catch (Exception e) {
			logger.debug("Exception " + e.getMessage());
			errorMsg = e.getMessage();
			throw new MailSendException(e.getMessage());
		}
		logger.info(" sendEmail():EXIT");
	}		
	
}
