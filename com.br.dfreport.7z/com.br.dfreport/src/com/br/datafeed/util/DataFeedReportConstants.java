package com.br.datafeed.util;

public final class DataFeedReportConstants {
		
	public static final String EMAIL_SUBJECT				= 	"email.subject";		
	public static final String SMTP_SERVER_HOST				= 	"email.server";	
	public static final String EMAIL_CONTENT_TYPE 			= 	"text/html";
	public static final String EMAIL_FROM_ADDRESS 			= 	"email.from.address";
	public static final String EMAIL_TO_ADDRESS 			= 	"email.to.address";
	public static final String EMAIL_CC_ADDRESS 			= 	"email.cc.address";
	public static final String EMAIL_BCC_ADDRESS 			= 	"email.bcc.address";
	public static final String EMAIL_REPLYTO 				= 	"email.replyto.address";
	
	public static final String QUERY_DF_STATISTICS_REPORT 	= 	"oradba.pkg_datafeed_report_api.usp_get_df_run_report";
	public static final String QUERY_DF_ERROR_REPORT 		=	"oradba.pkg_datafeed_report_api.usp_get_df_error_report";
	public static final String QUERY_DF_ERROR_XLS_REPORT 	=	"oradba.pkg_datafeed_report_api.usp_get_xls_error_report";
	public static final String QUERY_DF_INSTITUTION_REPORT 	= 	"oradba.pkg_datafeed_report_api.usp_get_institution_report";
	public static final String QUERY_DF_FIRSTACTIVITY_REPORT= 	"oradba.pkg_datafeed_report_api.usp_get_first_activity_report";
	public static final String QUERY_ALL_JOB_IDS 			= 	"oradba.pkg_datafeed_report_api.usp_get_df_jobs";
	public static final String QUERY_ALL_EMAIL_RECIPIENTS 	= 	"oradba.pkg_datafeed_report_api.usp_get_df_email_recipients";
	
	public static final String STATS_REPORT_BATCH_JOBS 		= 	"stats.report.batch.jobs";

	public static final String DATAFEED_EMAIL_XSLT_FILE		= 	"df.email.xslt.file";	
	public static final String TEMP_DIRECTORY 				= 	"temp.dir";
	public static final String JOB_LIST 					= 	"job.list";
	
	public static final String ATTACH_LOGFILES 				= 	"attach.logfiles";
	public static final String LOG_FILES_DIRECTORY 			= 	"log.files.directory";
	public static final String LOG_FILE_PREFIX 				= 	"log.file.prefix";
	
	//Adding Error records limit in Error sheet
	public static final String MAX_ERROR_RECORDS			= 	"max.error.records";
	public static final String DISCLAIMER					= 	"Total errors occurred today : ";
	
	public static final String REPORT_NAME					=	"report.name";
	//SER#58278 - PD Data feed batch report automation
	public static final String PD_REPORT					=	"PD";
	public static final String STATS_REPORT_PD_JOBS 		= 	"stats.report.PD.jobs";
	public static final String QUERY_PD_DF_STATISTICS_REPORT 	= 	"oradba.pkg_datafeed_report_api.usp_get_pd_df_run_report";
	public static final String QUERY_PD_DF_ERROR_REPORT 		=	"oradba.pkg_datafeed_report_api.usp_get_pd_df_error_report";
	public static final int MAX_ERROR_CNT_PD_CPP			=	5;

	//SER#58279 - CPP Data feed batch report automation
	public static final String CPP_REPORT					=	"CPP";
	public static final String STATS_REPORT_CPP_JOBS 		= 	"stats.report.CPP.jobs";
	public static final String QUERY_CPP_DF_STATISTICS_REPORT 	= 	"oradba.pkg_datafeed_report_api.usp_get_cpp_df_run_report";
	public static final String QUERY_CPP_DF_ERROR_REPORT 		=	"oradba.pkg_datafeed_report_api.usp_get_cpp_df_error_report";
	
	//SER#113404 - EU_DC Data feed batch report
	public static final String QUERY_EU_DF_STATISTICS_REPORT 	= 	"oradba.pkg_eu_datafeed_report_api.usp_get_eu_df_run_report";
	public static final String QUERY_EU_DF_ERROR_REPORT 		=	"oradba.pkg_eu_datafeed_report_api.usp_get_eu_df_error_report";
	public static final String QUERY_EU_DF_INSTITUTION_REPORT 	= 	"oradba.pkg_eu_datafeed_report_api.usp_get_eu_institution_report";
	public static final String QUERY_EU_DF_FIRSTACTIVITY_REPORT = 	"oradba.pkg_eu_datafeed_report_api.usp_get_eu_first_activity_report";
	public static final String QUERY_EU_DF_ERROR_XLS_REPORT 	=	"oradba.pkg_eu_datafeed_report_api.usp_get_eu_xls_error_report";
	public static final String DATA_CENTRE 						= 	"data.centre";
	
}
