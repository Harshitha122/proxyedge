package com.br.datafeed.util;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.br.datafeed.pojo.DataFeedErrors;
import com.br.datafeed.pojo.DataFeedInstitutions;
import com.br.datafeed.pojo.DataFeedStatistics;


@XmlRootElement(name="dataFeedReport")
@XmlAccessorType(XmlAccessType.FIELD)
public class EmailContent {
	
	@XmlElement(name = "Statistics")
	private List<DataFeedStatistics> dfStatisticsList = new ArrayList<DataFeedStatistics>();

	@XmlElement(name = "Errors")
	private List<DataFeedErrors> dfErrorsList = new ArrayList<DataFeedErrors>();
	
	@XmlElement(name = "UpdInstitutions")
	private List<DataFeedInstitutions> dfInstitutionList = new ArrayList<DataFeedInstitutions>();
	
	@XmlElement(name = "InstFirstActivity")
	private List<DataFeedInstitutions> dfInstFirstActivity = new ArrayList<DataFeedInstitutions>();

	public List<DataFeedStatistics> getDfStatisticsList() {
		return dfStatisticsList;
	}

	public void setDfStatisticsList(List<DataFeedStatistics> dfStatisticsList) {
		this.dfStatisticsList = dfStatisticsList;
	}

	public List<DataFeedErrors> getDfErrorsList() {
		return dfErrorsList;
	}

	public void setDfErrorsList(List<DataFeedErrors> dfErrorsList) {
		this.dfErrorsList = dfErrorsList;
	}

	public List<DataFeedInstitutions> getDfInstitutionList() {
		return dfInstitutionList;
	}

	public void setDfInstitutionList(List<DataFeedInstitutions> dfInstitutionList) {
		this.dfInstitutionList = dfInstitutionList;
	}

	public List<DataFeedInstitutions> getDfInstFirstActivity() {
		return dfInstFirstActivity;
	}

	public void setDfInstFirstActivity(List<DataFeedInstitutions> dfInstFirstActivity) {
		this.dfInstFirstActivity = dfInstFirstActivity;
	}
	
	@XmlElement(name = "ReportName")
	private String reportName = null;

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	@XmlElement(name = "cppJobRunNbr")
	private int cppJobRunNbr;
	
	public int getCppJobRunNbr() {
		return cppJobRunNbr;
	}
	public void setCppJobRunNbr(int cppJobRunNbr) {
		this.cppJobRunNbr = cppJobRunNbr;
	}
	
	@XmlElement(name="MaxErrorCnt")
	private int maxErrorCnt;
	
	public int getMaxErrorCnt() {
		return maxErrorCnt;
	}
	public void setMaxErrorCnt(int maxErrorCnt) {
		this.maxErrorCnt = maxErrorCnt;
	}
	
}
