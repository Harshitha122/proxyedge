package com.br.datafeed.util;

import java.util.ArrayList;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.adp.core.exception.MailSendException;
import com.br.batch.util.BatchUtil;
import com.br.batch.util.logger.BRLoggerFactory;
import com.br.batch.util.logger.IBRLogger;
import com.br.batch.util.property.PropertyMgr;

public class EmailManager {

	public static IBRLogger	logger	= BRLoggerFactory.getLogger(EmailManager.class);
	
	private InternetAddress[] recipients;
	private InternetAddress[] cc;
	private InternetAddress[] bcc;
	private InternetAddress[] replyto;
	private InternetAddress fromAddress;
	private String emailSubject;
	private String emailMessage;
	private String emailContentType;
	private String emailServer;
	private String[] attachmentFiles;
	
	public EmailManager(ArrayList<String> alRecipients) throws AddressException{
		setRecipients(alRecipients);
		setFromAddress(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.EMAIL_FROM_ADDRESS));
		setReplyto(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.EMAIL_REPLYTO));
		setCc(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.EMAIL_CC_ADDRESS));
		setBcc(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.EMAIL_BCC_ADDRESS));
		setEmailContentType(DataFeedReportConstants.EMAIL_CONTENT_TYPE);
		setEmailSubject(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.EMAIL_SUBJECT) + " - " + System.getProperty(BatchUtil.ENV_KEY));
		setEmailServer(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.SMTP_SERVER_HOST));
	}

	public InternetAddress[] getRecipients() {
		return recipients;
	}

	public void setRecipients(ArrayList<String> recipients) throws AddressException {
		this.recipients = new InternetAddress[recipients.size()];
		for (int i = 0; i < recipients.size(); i++) {
			this.recipients[i] = new InternetAddress(recipients.get(i));
		}
	}

	public InternetAddress[] getCc() {
		return cc;
	}

	public void setCc(String cc) throws AddressException{
		if(cc!=null && cc.trim().length()>0){
			String[] ccAddr=cc.split(",");
			this.cc = new InternetAddress[ccAddr.length];
			for (int i = 0; i < ccAddr.length; i++) {
				this.cc[i] = new InternetAddress(ccAddr[i]);
			}
		}
	}

	public InternetAddress[] getBcc() {
		return bcc;
	}

	public void setBcc(String bcc) throws AddressException {
		if(bcc!=null && bcc.trim().length()>0){
			String[] bccAddr=bcc.split(",");
			this.bcc = new InternetAddress[bccAddr.length];
			for (int i = 0; i < bccAddr.length; i++) {
				this.bcc[i] = new InternetAddress(bccAddr[i]);
			}
		}
	}

	public InternetAddress[] getReplyto() {
		return replyto;
	}

	public void setReplyto(String replyto) throws AddressException{
		if(replyto!=null && replyto.trim().length()>0){
			String[] replyAddress=replyto.split(",");
			this.replyto = new InternetAddress[replyAddress.length];
			for (int i = 0; i < replyAddress.length; i++) {
				this.replyto[i] = new InternetAddress(replyAddress[i]);
			}
		}
	}

	public InternetAddress getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) throws AddressException {
		this.fromAddress = new InternetAddress(fromAddress);
	}

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	public String getEmailMessage() {
		return emailMessage;
	}

	public void setEmailMessage(String emailMessage) {
		this.emailMessage = emailMessage;
	}

	public String getEmailContentType() {
		return emailContentType;
	}

	public void setEmailContentType(String emailContentType) {
		this.emailContentType = emailContentType;
	}

	public String getEmailServer() {
		return emailServer;
	}

	public void setEmailServer(String emailServer) {
		this.emailServer = emailServer;
	}

	public String[] getAttachmentFiles() {
		return attachmentFiles;
	}

	public void setAttachmentFiles(String[] attachmentFiles) {
		this.attachmentFiles = attachmentFiles;
	}

	public boolean sendMailwithAttachment(String emailContent,ArrayList<String> attachmentFiles,boolean priorityFlag) throws MailSendException {
		logger.info("sendMailwithAttachment(): ENTER");
		try {
				Properties props = System.getProperties();
				if (getEmailServer() != null && !getEmailServer().equals("".trim()))
					props.put("mail.smtp.host",getEmailServer());
				else {
					logger.error("Error occured while setting system property for mail server");
				
				}
				Session session = Session.getDefaultInstance(props, null);
				session.setDebug(false);

				javax.mail.Message msg = new MimeMessage(session);
				if (getFromAddress() != null) 
					msg.setFrom(getFromAddress());
				else
					logger.error("Error occured due to invalid or empty domain name");
		
			
				msg.setRecipients(javax.mail.Message.RecipientType.TO, getRecipients());
				msg.setRecipients(javax.mail.Message.RecipientType.CC, getCc());
				msg.setRecipients(javax.mail.Message.RecipientType.BCC, getBcc());
				msg.setReplyTo(getReplyto());
				if(priorityFlag){
					msg.setSubject(getEmailSubject()+" [Errors]");
					msg.setHeader("X-Priority", "1");
					msg.addHeader("X-Priority", "1");
				}else{
					msg.setSubject(getEmailSubject());
				}
				msg.setContent(emailContent, getEmailContentType());
				logger.debug("content type :"+getEmailContentType());
				
				if(attachmentFiles !=null && !attachmentFiles.isEmpty()){
					try {
						setFileAsAttachment(emailContent, msg, attachmentFiles);
					} catch (MessagingException mesgEx) {
						logger.error("Error attatching files");
						throw new Exception(mesgEx.getMessage());
					}
				}

				Transport.send(msg);
				logger.info("sendMailwithAttachment(): EXIT");
				return true;
			} catch (Exception ex) {
				logger.error("Error occured while sending email");
				throw new MailSendException(ex.getMessage());
			}
		}
	
	private void setFileAsAttachment(String emailContent, Message msg, ArrayList<String> filenames) throws MessagingException {
		logger.info("setFileAsAttachment(): ENTER");
		Multipart mp = new MimeMultipart();
		MimeBodyPart mbp = new MimeBodyPart();
		mbp.setContent(emailContent,getEmailContentType());
		mp.addBodyPart(mbp);
		if(filenames!=null && !filenames.isEmpty()){
			for (String sFileName:filenames) {
			try {
					mbp = new MimeBodyPart();
					if(sFileName!=null && sFileName.trim().length()>0){
						FileDataSource fds = new FileDataSource(sFileName);
						mbp.setDataHandler(new DataHandler(fds));
						mbp.setFileName(fds.getName());
					}
					mp.addBodyPart(mbp);
			} catch (Exception ex) {
				logger.error("Error Attaching files");
				throw new MessagingException(ex.getMessage());
			}
			}
		}
		msg.setContent(mp);
		logger.info("setFileAsAttachment: EXIT");
	}
	

}
