package com.br.datafeed.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

import com.adp.core.exception.MailSendException;
import com.br.batch.util.BRDBNames;
import com.br.batch.util.connection.DBConnectionMgr;
import com.br.batch.util.logger.BRLoggerFactory;
import com.br.batch.util.logger.IBRLogger;
import com.br.batch.util.property.PropertyMgr;
import com.br.datafeed.pojo.DataFeedErrors;
import com.br.datafeed.pojo.DataFeedInstitutions;
import com.br.datafeed.pojo.DataFeedStatistics;
import com.br.datafeed.util.DataFeedReportConstants;

public class DataFeedReportDAO {

	public static IBRLogger	log	= BRLoggerFactory.getLogger(DataFeedReportDAO.class);
	
	private final String reportName;
	
	public DataFeedReportDAO(String reportName){
		this.reportName = reportName;
	}
	public ArrayList<DataFeedStatistics> generateDFProcessingReport() throws SQLException,Exception {
		log.info("generateDFProcessingReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		DataFeedStatistics dfStatistics=null;
		ArrayList<DataFeedStatistics> alDataFeedStats=new ArrayList<DataFeedStatistics>();
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_DF_STATISTICS_REPORT + "(?,?,?,?)}";
		int sqlErrCode=0;
		String sqlMessage=null;
		int jobIdArray[] = null;
		//SER#113404
		String dataCentre =  PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.DATA_CENTRE); // Based on dataCentre the procedures are to be executed either US/EU
		//log.info("Datacentre value for EU is "+"EU"+" and for US it is "+null);
		try {
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);
			//SER#113404 - if statement states that we have to call US/EU
			if(dataCentre!=null && dataCentre.equalsIgnoreCase("EU") ){
				 sqlString = "{call "+ DataFeedReportConstants.QUERY_EU_DF_STATISTICS_REPORT + "(?,?,?,?)}";
				 log.info("Calling EU_DF_STATISTICS_REPORT: "+sqlString);				 
			}
			else{
			sqlString = "{call "+ DataFeedReportConstants.QUERY_DF_STATISTICS_REPORT + "(?,?,?,?)}";
			}
			if(conn!=null){
				
				if(reportName==null){
					if ( null != PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_BATCH_JOBS) &&
						0 < PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_BATCH_JOBS).length() )
					{
						jobIdArray = getJobIdArray(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_BATCH_JOBS));
					}
				}else if(reportName!=null && reportName.equalsIgnoreCase(DataFeedReportConstants.PD_REPORT)){
					if ( null != PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_PD_JOBS) &&
							0 < PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_PD_JOBS).length() )
						{
						jobIdArray = getJobIdArray(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_PD_JOBS));
					}
					
					sqlString = "{call "+ DataFeedReportConstants.QUERY_PD_DF_STATISTICS_REPORT + "(?,?,?,?)}";
					
				}
				
				cstmt = conn.prepareCall(sqlString);
					
				ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("NUMBER_ARRAY", conn);
				ARRAY array_to_pass = new ARRAY(descriptor, conn, jobIdArray);
				
					cstmt.setArray(1, array_to_pass);
					cstmt.registerOutParameter(2, OracleTypes.CURSOR);
					cstmt.registerOutParameter(3, OracleTypes.INTEGER); 
					cstmt.registerOutParameter(4, OracleTypes.VARCHAR);
					
					cstmt.execute();
					sqlErrCode = cstmt.getInt(3);//sql error code 
					sqlMessage = cstmt.getString(4);//sql message
				
				if ( sqlErrCode > 0 ) {
					log.error(
					"In Method: generateDFProcessingReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
							+ sqlErrCode + " SQL ERR MSG: " +sqlMessage+" for input "+ jobIdArray.toString());
					throw new Exception(sqlMessage);				
				}else{
					log.debug("In Method: generateDFProcessingReport()- " + sqlMessage );
				} 
	
				rs = (ResultSet) cstmt.getObject(2);
				if (rs != null)
		        {
				while (rs.next()) {
					
					dfStatistics=new DataFeedStatistics();
					dfStatistics.setJobId(rs.getInt("job_id"));
					dfStatistics.setJobName(rs.getString("job_name"));
					dfStatistics.setRunDate(rs.getDate("run_date"));
					dfStatistics.setRunNumber(rs.getInt("run_number"));
					String status=rs.getString("status");
					if(status!=null){
						if(status.equalsIgnoreCase("P"))
							status="Pending";
						else if(status.equalsIgnoreCase("R"))
							status="Running";
						else if(status.equalsIgnoreCase("S"))
							status="Successful";
						else if(status.equalsIgnoreCase("W"))
							status="Warnings";
						else if(status.equalsIgnoreCase("E"))
							status="Errors";
						else if(status.equalsIgnoreCase("U"))
							status="Undefined";
						else if(status.equalsIgnoreCase("M"))
							status="Warnings (Date Mismatch)";
					} else {
						status="Pending";
					}
					dfStatistics.setStatus(status);
					dfStatistics.setStartDate(rs.getTimestamp("start_time"));
					dfStatistics.setEndDate(rs.getTimestamp("end_time"));
					dfStatistics.setTotalErrors(rs.getInt("total_errors"));
					dfStatistics.setTotalInserts(rs.getInt("total_inserted"));
					dfStatistics.setTotalRecords(rs.getInt("total_records"));
					dfStatistics.setTotalRejects(rs.getInt("total_rejected"));
					dfStatistics.setTotalUpdates(rs.getInt("total_updated"));
					dfStatistics.setTotalWarnings(rs.getInt("total_warnings"));
					dfStatistics.setJobType(rs.getString("job_type"));
					if(dfStatistics.getJobType().equalsIgnoreCase("BN") || dfStatistics.getJobType().equalsIgnoreCase("DN"))
						dfStatistics.setColor("LIGHTBLUE");
					else if(status!=null && status.equalsIgnoreCase("Warnings (Date Mismatch)")){
						dfStatistics.setColor("YELLOW");
					}else{ 
						if(dfStatistics.getTotalWarnings()>0)
							dfStatistics.setColor("YELLOW");
						if(dfStatistics.getTotalRejects()>0)
							dfStatistics.setColor("ORANGE");
						if(dfStatistics.getTotalErrors()>0)
							dfStatistics.setColor("RED");
						if(dfStatistics.getTotalErrors()==0 && dfStatistics.getTotalRejects()==0 && dfStatistics.getTotalWarnings()==0)
							dfStatistics.setColor("DEFAULT");
					}
					alDataFeedStats.add(dfStatistics);
				}
		        }
				
			}else{
				log.info("Database connection object is null");
				throw new SQLException("Database connection object is null in DataFeedReportDAO.generateDFProcessingReport()");
			}
		 
		}catch (SQLException e) {
			log.info("SQLException occurred in stored procedure call " +
					sqlString+": "+e.getMessage());
			throw e;	
		} catch (Exception ex){
			log.info("Exception occurred in stored procedure call " +
					sqlString+": "+ex.getMessage());
			throw ex;
		}
		finally {		
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);			
			log.info("generateDFProcessingReport(): EXIT");
		}
		return alDataFeedStats;
	}
	/*
	 * This method is used to get the statistical information for CPP report
	 */
	public ArrayList<DataFeedStatistics> generateCPPDFProcessingReport() throws SQLException,Exception {
		log.info("generateCPPDFProcessingReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSet schJobs = null;
		ResultSet unSchJobs = null;
		DataFeedStatistics dfStatistics=null;
		ArrayList<DataFeedStatistics> alDataFeedStats=new ArrayList<DataFeedStatistics>();
		String sqlString = "";	
		int sqlErrCode=0;
		int cppJobRunNbr = 0;
		String sqlMessage=null;
		int jobIdArray[] = null;

		try {			
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);
			if(conn!=null){

				if ( null != PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_CPP_JOBS) &&
						0 < PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_CPP_JOBS).length() )
				{
					jobIdArray = getJobIdArray(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_CPP_JOBS));
				}

				sqlString = "{call "+ DataFeedReportConstants.QUERY_CPP_DF_STATISTICS_REPORT + "(?,?,?,?,?,?,?)}";

				cstmt = conn.prepareCall(sqlString);

				ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("NUMBER_ARRAY", conn);
				ARRAY array_to_pass = new ARRAY(descriptor, conn, jobIdArray);

				cstmt.setArray(1, array_to_pass);
				cstmt.registerOutParameter(2, OracleTypes.CURSOR);
				cstmt.registerOutParameter(3, OracleTypes.CURSOR);
				cstmt.registerOutParameter(4, OracleTypes.CURSOR);
				cstmt.registerOutParameter(5, OracleTypes.INTEGER);
				cstmt.registerOutParameter(6, OracleTypes.INTEGER); 
				cstmt.registerOutParameter(7, OracleTypes.VARCHAR);

				cstmt.execute();
				cppJobRunNbr = cstmt.getInt(5);
				sqlErrCode = cstmt.getInt(6);//sql error code 
				sqlMessage = cstmt.getString(7);//sql message
				log.info("cppJobRunNbr...." +cppJobRunNbr);


				if ( sqlErrCode > 0 ) {
					log.error(
							"In Method: generateCPPDFProcessingReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
							+ sqlErrCode + " SQL ERR MSG: " +sqlMessage+" for input "+ jobIdArray.toString());
					throw new Exception(sqlMessage);				
				}else{
					log.debug("In Method: generateCPPDFProcessingReport()- " + sqlMessage );
				} 

				rs = (ResultSet) cstmt.getObject(2);
				schJobs = (ResultSet) cstmt.getObject(3);
				unSchJobs = (ResultSet) cstmt.getObject(4);
				ArrayList<Integer> scArrayList = new ArrayList<Integer>();
				ArrayList<Integer> runArrayList = new ArrayList<Integer>();
				String[] jobIdStringArray = null;
				String jobString = "";
				//Scheduled jobs
				while (schJobs.next()) {
					jobString = schJobs.getString("scheduled_jobs");

				}
				if(jobString != null) {
					jobIdStringArray = jobString.split(",");
					for(String s:jobIdStringArray) {
						scArrayList.add(Integer.parseInt(s));
					}
				}

				if (rs != null)
				{
					while (rs.next()) {

						dfStatistics=new DataFeedStatistics();
						dfStatistics.setJobId(rs.getInt("job_id"));
						dfStatistics.setJobName(rs.getString("job_name"));
						dfStatistics.setRunDate(rs.getDate("run_date"));
						dfStatistics.setRunNumber(rs.getInt("run_number"));
						String status=rs.getString("status");
						if(status!=null){
							if(status.equalsIgnoreCase("P"))
								status="Pending";
							else if(status.equalsIgnoreCase("R"))
								status="Running";
							else if(status.equalsIgnoreCase("S"))
								status="Successful";
							else if(status.equalsIgnoreCase("W"))
								status="Warnings";
							else if(status.equalsIgnoreCase("E"))
								status="Errors";
							else if(status.equalsIgnoreCase("U"))
								status="Undefined";
							else if(status.equalsIgnoreCase("M"))
								status="Warnings (Date Mismatch)";
						} else {
							status="Pending";
						}
						dfStatistics.setStatus(status);
						dfStatistics.setStartDate(rs.getTimestamp("start_time"));
						dfStatistics.setEndDate(rs.getTimestamp("end_time"));
						dfStatistics.setTotalErrors(rs.getInt("total_errors"));
						dfStatistics.setTotalInserts(rs.getInt("total_inserted"));
						dfStatistics.setTotalRecords(rs.getInt("total_records"));
						dfStatistics.setTotalRejects(rs.getInt("total_rejected"));
						dfStatistics.setTotalUpdates(rs.getInt("total_updated"));
						dfStatistics.setTotalWarnings(rs.getInt("total_warnings"));
						dfStatistics.setJobType(rs.getString("job_type"));
						if(dfStatistics.getJobType().equalsIgnoreCase("BN") || dfStatistics.getJobType().equalsIgnoreCase("DN"))
							dfStatistics.setColor("LIGHTBLUE");
						else if(status!=null && status.equalsIgnoreCase("Warnings (Date Mismatch)")){
							dfStatistics.setColor("YELLOW");
						}else{ 
							if(dfStatistics.getTotalWarnings()>0)
								dfStatistics.setColor("YELLOW");
							if(dfStatistics.getTotalRejects()>0)
								dfStatistics.setColor("ORANGE");
							if(dfStatistics.getTotalErrors()>0)
								dfStatistics.setColor("RED");
							if(dfStatistics.getTotalErrors()==0 && dfStatistics.getTotalRejects()==0 && dfStatistics.getTotalWarnings()==0)
								dfStatistics.setColor("DEFAULT");
						}
						dfStatistics.setCppJobRunNbr(cppJobRunNbr);
						alDataFeedStats.add(dfStatistics);
						int jobId = dfStatistics.getJobId();
						if (scArrayList.contains(jobId)) {
							runArrayList.add(jobId);
						}
					}

				}	

				for (int i: scArrayList) {
					boolean isExists = false; 

					if(runArrayList.contains(i)) {
						isExists =true;	
					}
					if(!isExists){
						dfStatistics=new DataFeedStatistics();
						dfStatistics.setCppJobRunNbr(cppJobRunNbr);
						dfStatistics.setJobId(i);
						dfStatistics.setStatus("Not Yet Started");
						dfStatistics.setColor("PURPLE");
						alDataFeedStats.add(dfStatistics);
					}
				}

				if(unSchJobs !=null) {
					while (unSchJobs.next()) {
						jobString = unSchJobs.getString("unscheduled_jobs");

					} 
					if(jobString != null) {
						jobIdStringArray = jobString.split(",");

						for(String s:jobIdStringArray) {
							dfStatistics=new DataFeedStatistics();
							dfStatistics.setJobId(Integer.parseInt(s));
							dfStatistics.setStatus("Not Scheduled");
							dfStatistics.setColor("BLUE");
							alDataFeedStats.add(dfStatistics);
						}

					}
				}      

			}else{
				log.info("Database connection object is null");
				throw new SQLException("Database connection object is null in DataFeedReportDAO.generateCPPDFProcessingReport()");
			}
		} catch (SQLException e) {
			log.info("SQLException occurred in stored procedure call " +
					"pkg_datafeed_report_api.usp_get_cpp_df_run_report"+e.getMessage());
			throw e;	
		} catch (Exception ex){
			log.info("Exception occurred in stored procedure call " +
					"pkg_datafeed_report_api.usp_get_cpp_df_run_report"+ex.getMessage());
			throw ex;
		}
		finally {		
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);			
			log.info("generateCPPDFProcessingReport(): EXIT");
		}
		return alDataFeedStats;
	}
	
	private int[] getJobIdArray(String jobIdList)throws Exception {
		
		if ( null == jobIdList || jobIdList.length() == 0 )
			return null;
		
		String[] jobIdStringArray = jobIdList.split(",");
		int jobIdArray[] = new int[jobIdStringArray.length];
		
		try {
			for (int index=0; index < jobIdStringArray.length; index++){
				jobIdArray[index] = Integer.parseInt(jobIdStringArray[index]);
			}
		} catch (NumberFormatException nfe){
			log.error("Error parsing jobIdList, processing can continue" + nfe.getMessage() );
			throw new Exception(nfe.getMessage());
		}
		
		return jobIdArray;
		
	}

	public ArrayList<DataFeedErrors> generateErrorReport() throws SQLException,Exception {
		log.info("generateErrorReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		DataFeedErrors dfErrors=null;
		ArrayList<DataFeedErrors> alDataFeedErrors=new ArrayList<DataFeedErrors>();
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_DF_ERROR_REPORT + "(?,?,?)}";
		int sqlErrCode=0;
		String sqlMessage=null;
		//SER#113404
		String dataCentre = PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.DATA_CENTRE); // Based on dataCentre the procedures are to be executed either US/EU
		//log.info("Datacentre value for EU is "+dataCentre+" for US it is "+null);
		try {
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);
			//SER#113404 - if statement states that we have to call US/EU
			if(dataCentre!=null && dataCentre.equalsIgnoreCase("EU")){
				 sqlString = "{call "+ DataFeedReportConstants.QUERY_EU_DF_ERROR_REPORT + "(?,?,?)}"; // Based on dataCentre the procedures are to be executed either US/EU
				 log.info("Calling EU_DF_ERROR_REPORT: "+"\t"+sqlString);
			}	
			if(conn!=null){
				cstmt = conn.prepareCall(sqlString);
				cstmt.registerOutParameter(1, OracleTypes.CURSOR);
				cstmt.registerOutParameter(2, OracleTypes.INTEGER); 
				cstmt.registerOutParameter(3, OracleTypes.VARCHAR);
				
				cstmt.execute();
					
				sqlErrCode = cstmt.getInt(2);//sql error code 
				sqlMessage = cstmt.getString(3);//sql message
				
				if ( sqlErrCode > 0 ) {
					log.error(
					"In Method: generateErrorReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
							+ sqlErrCode + " SQL ERR MSG: " +sqlMessage );
					throw new Exception(sqlMessage);				
				}else{
					log.debug("In Method: generateErrorReport()- " + sqlMessage );
				} 
				
				rs = (ResultSet) cstmt.getObject(1);
				
				while (rs.next()) {
					dfErrors=new DataFeedErrors();
					dfErrors.setFeedId(rs.getString("feed_id"));
					dfErrors.setFeedDate(rs.getString("feed_date"));
					dfErrors.setErrorType(rs.getString("error_type"));
					dfErrors.setErrorMessage(rs.getString("error_message"));
					dfErrors.setErrorMsgCount(rs.getInt("error_msg_count"));
					alDataFeedErrors.add(dfErrors);
				}
			}else{
				log.info("Database connection object is null");
				throw new SQLException("Database connection object is null in DataFeedReportDAO.generateErrorReport()");
			}

		} catch (SQLException e) {
			log.error("SQLException occured in stored procedure call " +sqlString+
					": "+e.getMessage());
			throw e;	
		} catch(Exception ex){
			log.error("Exception occured in stored procedure call " +sqlString+
					": "+ex.getMessage());
			throw ex;	
		}finally {
		
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("generateErrorReport(): EXIT");
		}
		return alDataFeedErrors;
	}
	
	public ArrayList<DataFeedErrors> generatePDErrorReport() throws SQLException,Exception {
		log.info("generatePDErrorReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		DataFeedErrors dfErrors=null;
		ArrayList<DataFeedErrors> alDataFeedErrors=new ArrayList<DataFeedErrors>();
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_PD_DF_ERROR_REPORT + "(?,?,?,?,?)}";
		int sqlErrCode=0;
		String sqlMessage=null;
		
		try {
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);	
			int errorCnt = DataFeedReportConstants.MAX_ERROR_CNT_PD_CPP;
			if ( null != PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS) &&
					PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS).length() >0)
				{
					errorCnt = Integer.parseInt(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS));
					log.debug("max error count from property:"+errorCnt);
				}
			
			if(conn!=null){
				cstmt = conn.prepareCall(sqlString);
				cstmt.setString(1, reportName);
				cstmt.setInt(2, errorCnt);
				cstmt.registerOutParameter(3, OracleTypes.CURSOR);
				cstmt.registerOutParameter(4, OracleTypes.INTEGER); 
				cstmt.registerOutParameter(5, OracleTypes.VARCHAR);
				
				cstmt.execute();
					
				sqlErrCode = cstmt.getInt(4);//sql error code 
				sqlMessage = cstmt.getString(5);//sql message
				
				if ( sqlErrCode > 0 ) {
					log.error(
					"In Method: generatePDErrorReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
							+ sqlErrCode + " SQL ERR MSG: " +sqlMessage );
					throw new Exception(sqlMessage);				
				}else{
					log.debug("In Method: generatePDErrorReport()- " + sqlMessage );
				} 
				
				rs = (ResultSet) cstmt.getObject(3);
				
				while (rs.next()) {
					dfErrors=new DataFeedErrors();
					dfErrors.setFeedId(rs.getString("feed_id"));
					dfErrors.setFeedDate(rs.getString("feed_date"));
					dfErrors.setErrorType(rs.getString("error_type"));
					dfErrors.setErrorMessage(rs.getString("error_message"));
					dfErrors.setErrorMsgCount(rs.getInt("error_msg_count"));
					alDataFeedErrors.add(dfErrors);
				}
			}else{
				log.info("Database connection object is null");
				throw new SQLException("Database connection object is null in DataFeedReportDAO.generatePDErrorReport()");
			}

		} catch (SQLException e) {
			log.error("SQLException occured in stored procedure call " +
					"pkg_datafeed_report_api.usp_get_pd_df_error_report"+e.getMessage());
			throw e;	
		} catch(Exception ex){
			log.error("Exception occured in stored procedure call " +
					"pkg_datafeed_report_api.usp_get_pd_df_error_report"+ex.getMessage());
			throw ex;	
		}finally {
		
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("generatePDErrorReport(): EXIT");
		}
		return alDataFeedErrors;
	}
	public ArrayList<DataFeedErrors> generateCPPErrorReport() throws SQLException,Exception {
		log.info("generateCPPErrorReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		DataFeedErrors dfErrors=null;
		ArrayList<DataFeedErrors> alDataFeedErrors=new ArrayList<DataFeedErrors>();
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_CPP_DF_ERROR_REPORT + "(?,?,?,?)}";
		int sqlErrCode=0;
		String sqlMessage=null;
		
		try {
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);	
			int errorCnt = DataFeedReportConstants.MAX_ERROR_CNT_PD_CPP;
			if ( null != PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS) &&
					PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS).length() >0)
				{
					errorCnt = Integer.parseInt(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.MAX_ERROR_RECORDS));
					log.debug("error count from property.............."+errorCnt);
				}
			
			if(conn!=null){
				cstmt = conn.prepareCall(sqlString);
				cstmt.setInt(1, errorCnt);
				cstmt.registerOutParameter(2, OracleTypes.CURSOR);
				cstmt.registerOutParameter(3, OracleTypes.INTEGER); 
				cstmt.registerOutParameter(4, OracleTypes.VARCHAR);
				
				cstmt.execute();
					
				sqlErrCode = cstmt.getInt(3);//sql error code 
				sqlMessage = cstmt.getString(4);//sql message
				
				if ( sqlErrCode > 0 ) {
					log.error(
					"In Method: generateCPPErrorReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
							+ sqlErrCode + " SQL ERR MSG: " +sqlMessage );
					throw new Exception(sqlMessage);				
				}else{
					log.debug("In Method: generateCPPErrorReport()- " + sqlMessage );
				} 
				
				rs = (ResultSet) cstmt.getObject(2);
				
				while (rs.next()) {
					dfErrors=new DataFeedErrors();
					dfErrors.setFeedId(rs.getString("feed_id"));
					dfErrors.setFeedDate(rs.getString("feed_date"));
					dfErrors.setErrorType(rs.getString("error_type"));
					dfErrors.setErrorMessage(rs.getString("error_message"));
					dfErrors.setErrorMsgCount(rs.getInt("error_msg_count"));
					alDataFeedErrors.add(dfErrors);
				}
			}else{
				log.info("Database connection object is null");
				throw new SQLException("Database connection object is null in DataFeedReportDAO.generateCPPErrorReport()");
			}

		} catch (SQLException e) {
			log.error("SQLException occured in stored procedure call " +
					"pkg_datafeed_report_api.usp_get_cpp_df_error_report"+e.getMessage());
			throw e;	
		} catch(Exception ex){
			log.error("Exception occured in stored procedure call " +
					"pkg_datafeed_report_api.usp_get_cpp_df_error_report"+ex.getMessage());
			throw ex;	
		}finally {
		
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("generateCPPErrorReport(): EXIT");
		}
		return alDataFeedErrors;
	}
	
	public ArrayList<DataFeedInstitutions> generateInstitutionReport() throws SQLException,Exception {
		log.info("generateInstitutionReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		StringBuffer sbInstitutions=new StringBuffer();		
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_DF_INSTITUTION_REPORT + "(?,?,?)}";
		ArrayList<DataFeedInstitutions> dfInstitutions=new ArrayList<DataFeedInstitutions>();
		DataFeedInstitutions dfInst=new DataFeedInstitutions();
		int sqlErrCode=0;
		String sqlMessage=null;
		//SER#113404
		String dataCentre = PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.DATA_CENTRE); // Based on dataCentre the procedures are to be executed either US/EU
		//log.info("Datacentre value for EU is "+dataCentre+" for US it is "+null);
		try {
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);
			//SER#113404 - if statement states that we have to call US/EU
			if(dataCentre !=null && dataCentre.equalsIgnoreCase("EU")){
				sqlString = "{call "+ DataFeedReportConstants.QUERY_EU_DF_INSTITUTION_REPORT + "(?,?,?)}";
				log.info("Calling EU_DF_INSTITUTION_REPORT: "+"\t"+sqlString);
			}
			if(conn!=null){
				cstmt = conn.prepareCall(sqlString);
				cstmt.registerOutParameter(1, OracleTypes.CURSOR);
				cstmt.registerOutParameter(2, OracleTypes.INTEGER); 
				cstmt.registerOutParameter(3, OracleTypes.VARCHAR);
				
				cstmt.execute();
					
				sqlErrCode = cstmt.getInt(2);//sql error code 
				sqlMessage = cstmt.getString(3);//sql message
				
				if ( sqlErrCode > 0 ) {
					log.error(
					"In Method: generateInstitutionReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
							+ sqlErrCode + " SQL ERR MSG: " +sqlMessage );
					throw new Exception(sqlMessage);				
				}else{
					log.debug("In Method: generateInstitutionReport()- " + sqlMessage );
				} 
				
				rs = (ResultSet) cstmt.getObject(1);
				while (rs.next()){
					sbInstitutions.append(rs.getString("inst_id").trim()+", ");
				}
				
				String sInst=sbInstitutions.toString();
				if(sInst!=null && sInst.trim().length()>0){
					sInst=sInst.substring(0,sInst.lastIndexOf(","));
					dfInst.setInstId(sInst);
					dfInstitutions.add(dfInst);
				}
			}else{
				log.info("Database connection object is null");
				throw new SQLException("Database connection object is null in DataFeedReportDAO.generateInstitutionReport()");
			}
		}  catch (SQLException e) {
			log.error("SQLException occured in stored procedure call " +sqlString+
					": "+e.getMessage());
			throw e;	
		} catch(Exception ex){
			log.error("Exception occured in stored procedure call " +sqlString+
					": "+ex.getMessage());
			throw ex;	
		} finally {
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("generateInstitutionReport(): EXIT");
		}
		return dfInstitutions;
	}
	
	public ArrayList<DataFeedInstitutions> generateFirstActivityReport() throws SQLException,Exception {
		log.info("generateFirstActivityReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		StringBuffer sbFirstActivityInst=new StringBuffer();
		ArrayList<DataFeedInstitutions> dfFirstActivityInst=new ArrayList<DataFeedInstitutions>();
		DataFeedInstitutions dfInst=new DataFeedInstitutions();
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_DF_FIRSTACTIVITY_REPORT + "(?,?,?)}";
		int sqlErrCode=0;
		String sqlMessage=null;
		//SER#113404
		String dataCentre = PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.DATA_CENTRE); // Based on dataCentre the procedures are to executed either US/EU
		//log.info("Datacentre value for EU is "+dataCentre+" and for US it is "+null);
		try {
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);
			//SER#113404 - if statement states that we have to call US/EU
			if(dataCentre !=null && dataCentre.equalsIgnoreCase("EU")){
				sqlString = "{call "+ DataFeedReportConstants.QUERY_EU_DF_FIRSTACTIVITY_REPORT + "(?,?,?)}";
				 log.info("Calling EU_DF_FIRSTACTIVITY_REPORT: "+sqlString);
			}
			if(conn!=null){
				cstmt = conn.prepareCall(sqlString);
				cstmt.registerOutParameter(1, OracleTypes.CURSOR);
				cstmt.registerOutParameter(2, OracleTypes.INTEGER); 
				cstmt.registerOutParameter(3, OracleTypes.VARCHAR);
				
				cstmt.execute();
					
				sqlErrCode = cstmt.getInt(2);//sql error code 
				sqlMessage = cstmt.getString(3);//sql message
				
				if ( sqlErrCode > 0 ) {
					log.error(
					"In Method: generateFirstActivityReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
							+ sqlErrCode + " SQL ERR MSG: " +sqlMessage );
					throw new Exception(sqlMessage);				
				}else{
					log.debug("In Method: generateFirstActivityReport()- " + sqlMessage );
				} 
				
				rs = (ResultSet) cstmt.getObject(1);
				
				while (rs.next()) {
					sbFirstActivityInst.append(rs.getString("inst_id").trim()+", ");
				}
				String sFirstActivity=sbFirstActivityInst.toString();
				if(sFirstActivity!=null && sFirstActivity.trim().length()>0){
					sFirstActivity=sFirstActivity.substring(0,sFirstActivity.lastIndexOf(","));
					dfInst.setInstId(sFirstActivity);
					dfFirstActivityInst.add(dfInst);
				}
			}else{
				log.info("Database connection object is null");
				throw new SQLException("Database connection object is null in DataFeedReportDAO.generateFirstActivityReport()");
			}
		} catch (SQLException e) {
			
			log.error("SQLException occured in stored procedure call " +
					sqlString+": "+e.getMessage());
			throw e;	
		} catch(Exception ex){
			log.error("Exception occured in stored procedure call " +
					sqlString+": "+ex.getMessage());
			throw ex;	
		}finally {
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("generateFirstActivityReport(): EXIT");
		}
		return dfFirstActivityInst;
	}
	
	public  ArrayList<String> getAllEmailRecipients(String reportName) throws SQLException,Exception {
		log.info("getAllEmailRecipients(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ArrayList<String> recipientEmails=new ArrayList<String>();			
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_ALL_EMAIL_RECIPIENTS + "(?,?,?,?)}";
		int sqlErrCode=0;
		String sqlMessage=null;
		
		try {
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);		
			if(conn!=null){
				cstmt = conn.prepareCall(sqlString);
				cstmt.setString(1, reportName);
				cstmt.registerOutParameter(2, OracleTypes.CURSOR);
				cstmt.registerOutParameter(3, OracleTypes.INTEGER); 
				cstmt.registerOutParameter(4, OracleTypes.VARCHAR);
				
				cstmt.execute();
					
				sqlErrCode = cstmt.getInt(3);//sql error code 
				sqlMessage = cstmt.getString(4);//sql message
				
				if ( sqlErrCode > 0 ) {
					log.error(
					"In Method: getAllEmailRecipients() - Sql Exception from stored Procedure - SQL ERR CODE: "
							+ sqlErrCode + " SQL ERR MSG: " +sqlMessage );
					throw new Exception(sqlMessage);				
				}else{
					log.debug("In Method: getAllEmailRecipients()- " + sqlMessage );
				} 
				
				rs = (ResultSet) cstmt.getObject(2);
				
				while (rs.next()) {
					recipientEmails.add(rs.getString("email_address"));
				}
			}else{
				log.error("Database connection object is null");
				throw new SQLException("Database connection object is null in DataFeedReportDAO.getAllEmailRecipients()");	
			}
		} catch (SQLException e) {
			log.error("SQLException occurred while getting email recipients "+e.getMessage());
			throw e;	
		}catch (Exception ex){
			log.error("Exception occurred while getting email recipients"+ex.getMessage());
			throw ex;
		} finally {
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("getAllEmailRecipients(): EXIT");
		}
		return recipientEmails;
	}
	
	public String generateXLSDFProcessingReport(String strTempDirectory) throws MailSendException {
		log.info("generateXLSDFProcessingReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		HSSFRow row = null;
		String job_id = null;
		String total_records = null;
		String total_inserts = null;
		String total_updates = null;
		String total_errors = null;
		String total_warnings = null;
		String total_rejects = null;
		String sExcelFileName = "PE_Datafeed_Report_"+getReportCurrentDateTimeAsString()+".xls";		
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_DF_STATISTICS_REPORT + "(?,?,?,?)}";
		String sFilePath=null;		
		String jobName=null,runDate=null,startTime=null,endTime=null,runNumber=null,status=null;
		int sqlErrCode=0;
		String sqlMessage=null;
		int jobIdArray[] = null;
		String dataCentre =  PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.DATA_CENTRE); // Based on dataCentre the procedures are to be executed either US/EU
		try {
			if(dataCentre!=null && dataCentre.equalsIgnoreCase("EU") ){
				 sqlString = "{call "+ DataFeedReportConstants.QUERY_EU_DF_STATISTICS_REPORT + "(?,?,?,?)}";
				 log.info("Calling EU_DF_STATISTICS_REPORT: "+sqlString);				 
			}
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);
			cstmt = conn.prepareCall(sqlString);
			
			if ( null != PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_BATCH_JOBS) &&
					0 < PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_BATCH_JOBS).length() ){
				jobIdArray = getJobIdArray(PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.STATS_REPORT_BATCH_JOBS));
			}
				
			ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("NUMBER_ARRAY", conn);
			ARRAY array_to_pass = new ARRAY(descriptor, conn, jobIdArray);
					
			cstmt.setArray(1, array_to_pass);
			cstmt.registerOutParameter(2, OracleTypes.CURSOR);
			cstmt.registerOutParameter(3, OracleTypes.INTEGER); 
			cstmt.registerOutParameter(4, OracleTypes.VARCHAR);
			
			cstmt.execute();
				
			sqlErrCode = cstmt.getInt(3);//sql error code 
			sqlMessage = cstmt.getString(4);//sql message
					
			if ( sqlErrCode > 0 ) {
				log.error(
				"In Method: generateXLSDFProcessingReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
						+ sqlErrCode + " SQL ERR MSG: " +sqlMessage+" for input "+ jobIdArray.toString());
				throw new Exception(sqlMessage);				
			}else{
				log.debug("In Method: generateXLSDFProcessingReport()- " + sqlMessage );
			} 
			
			rs = (ResultSet) cstmt.getObject(2);

			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet sheet = workbook.createSheet("DF Processing Report");
			HSSFCellStyle style = workbook.createCellStyle();
			HSSFCellStyle style1 = workbook.createCellStyle();

			HSSFFont font = workbook.createFont();
			font.setFontName(HSSFFont.FONT_ARIAL);
			font.setFontHeightInPoints((short) 10);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font.setColor(HSSFColor.WHITE.index);
			style.setFont(font);

			style.setAlignment(HSSFCellStyle.ALIGN_JUSTIFY);
			style.setFillBackgroundColor(HSSFColor.AQUA.index);
			style.setFillPattern(HSSFCellStyle.BIG_SPOTS);
			style.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			style.setBorderBottom(HSSFCellStyle.BORDER_THICK);
			style.setBorderLeft(HSSFCellStyle.BORDER_THICK);
			style.setBorderRight(HSSFCellStyle.BORDER_THICK);
			style.setBorderTop(HSSFCellStyle.BORDER_THICK);

			style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style1.setBorderTop(HSSFCellStyle.BORDER_THIN);

			HSSFRow headerRow = sheet.createRow((short) 0);
			
			headerRow.createCell(0).setCellValue(new HSSFRichTextString("JOB ID"));
			headerRow.createCell(1).setCellValue(new HSSFRichTextString("JOB Name"));
			headerRow.createCell(2).setCellValue(new HSSFRichTextString("Run Date"));
			headerRow.createCell(3).setCellValue(new HSSFRichTextString("Start Time"));
			headerRow.createCell(4).setCellValue(new HSSFRichTextString("End Time"));
			headerRow.createCell(5).setCellValue(new HSSFRichTextString("Run Number"));
			headerRow.createCell(6).setCellValue(new HSSFRichTextString("Status"));			
			headerRow.createCell(7).setCellValue(new HSSFRichTextString("Total Inserts"));
			headerRow.createCell(8).setCellValue(new HSSFRichTextString("Total Updates"));
			headerRow.createCell(9).setCellValue(new HSSFRichTextString("Total Errors"));
			headerRow.createCell(10).setCellValue(new HSSFRichTextString("Total Warnings"));
			headerRow.createCell(11).setCellValue(new HSSFRichTextString("Total Rejects"));
			headerRow.createCell(12).setCellValue(new HSSFRichTextString("Total Records"));
			
			(headerRow.getCell(0)).setCellStyle(style);
			(headerRow.getCell(1)).setCellStyle(style);
			(headerRow.getCell(2)).setCellStyle(style);
			(headerRow.getCell(3)).setCellStyle(style);
			(headerRow.getCell(4)).setCellStyle(style);
			(headerRow.getCell(5)).setCellStyle(style);
			(headerRow.getCell(6)).setCellStyle(style);
			(headerRow.getCell(7)).setCellStyle(style);
			(headerRow.getCell(8)).setCellStyle(style);
			(headerRow.getCell(9)).setCellStyle(style);
			(headerRow.getCell(10)).setCellStyle(style);
			(headerRow.getCell(11)).setCellStyle(style);
			(headerRow.getCell(12)).setCellStyle(style);

			while (rs.next()) {
				row = sheet.createRow((short) (rs.getRow()));
				if (((rs.getString("total_inserted").equalsIgnoreCase("0"))
						&& (rs.getString("total_updated")
								.equalsIgnoreCase("0"))
								&& (rs.getString("total_errors")
										.equalsIgnoreCase("0"))
										&& (rs.getString("total_warnings")
												.equalsIgnoreCase("0"))
												&& (rs.getString("total_rejected")
														.equalsIgnoreCase("0")) && (rs.getString("total_records").equalsIgnoreCase("0")))) {
					job_id = ((rs.getString("job_id")) + ("*"));
					total_records = "-";
					total_inserts = "-";
					total_updates = "-";
					total_errors = "-";
					total_warnings = "-";
					total_rejects = "-";
				} else {
					job_id = rs.getString("job_id");
					jobName=rs.getString("job_name");
					runDate=runDateFormat(rs.getDate("run_date"));		
					startTime=TimeFormat(rs.getTimestamp("start_time"));
					endTime=TimeFormat(rs.getTimestamp("end_time"));
					runNumber=rs.getString("run_number");
					status=rs.getString("status");
					if(status!=null){
						if(status.equalsIgnoreCase("P"))
							status="Pending";
						else if(status.equalsIgnoreCase("R"))
							status="Running";
						else if(status.equalsIgnoreCase("S"))
							status="Successful";
						else if(status.equalsIgnoreCase("W"))
							status="Warnings";
						else if(status.equalsIgnoreCase("E"))
							status="Errors";
						else if(status.equalsIgnoreCase("U"))
							status="Undefined";
						else if(status.equalsIgnoreCase("M"))
							status="Warnings (Date Mismatch)";
					}
					total_records = rs.getString("total_records");
					total_inserts = rs.getString("total_inserted");
					total_updates = rs.getString("total_updated");
					total_errors  = rs.getString("total_errors");
					total_warnings= rs.getString("total_warnings");
					total_rejects = rs.getString("total_rejected");
				}

				row.createCell(0).setCellValue(new HSSFRichTextString(job_id));
				row.createCell(1).setCellValue(new HSSFRichTextString(jobName));
				row.createCell(2).setCellValue(new HSSFRichTextString(runDate));
				row.createCell(3).setCellValue(new HSSFRichTextString(startTime));
				row.createCell(4).setCellValue(new HSSFRichTextString(endTime));
				row.createCell(5).setCellValue(new HSSFRichTextString(runNumber));
				row.createCell(6).setCellValue(new HSSFRichTextString(status));
				row.createCell(7).setCellValue(new HSSFRichTextString(total_inserts));
				row.createCell(8).setCellValue(new HSSFRichTextString(total_updates));
				row.createCell(9).setCellValue(new HSSFRichTextString(total_errors));
				row.createCell(10).setCellValue(new HSSFRichTextString(total_warnings));
				row.createCell(11).setCellValue(new HSSFRichTextString(total_rejects));
				row.createCell(12).setCellValue(new HSSFRichTextString(total_records));
				
				(row.getCell(0)).setCellStyle(style1);
				(row.getCell(1)).setCellStyle(style1);
				(row.getCell(2)).setCellStyle(style1);
				(row.getCell(3)).setCellStyle(style1);
				(row.getCell(4)).setCellStyle(style1);
				(row.getCell(5)).setCellStyle(style1);
				(row.getCell(6)).setCellStyle(style1);
				(row.getCell(7)).setCellStyle(style1);
				(row.getCell(8)).setCellStyle(style1);
				(row.getCell(9)).setCellStyle(style1);
				(row.getCell(10)).setCellStyle(style1);
				(row.getCell(11)).setCellStyle(style1);
				(row.getCell(12)).setCellStyle(style1);
			}
			workbook=generateXLSDFErrorReport(workbook);
			FileOutputStream fileOut = new FileOutputStream(new File(
					strTempDirectory+sExcelFileName));
			workbook.write(fileOut);
			fileOut.close();
			sFilePath = strTempDirectory +sExcelFileName;
		} catch (SQLException e) {
			log.error("SQLException occurred while preparing report attachment "+e.getMessage());
			throw new MailSendException(e.getMessage());	
		}catch (Exception ex){
			log.error("Exception occurred while preparing report attachment"+ex.getMessage());
			throw new MailSendException(ex.getMessage());
		} finally {
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("generateXLSDFProcessingReport(): EXIT");
		}
		return sFilePath;
	}
	
	public StringBuffer getJobIDS() throws Exception {
		log.info("getJobIDS(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		StringBuffer buf = new StringBuffer();		
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_ALL_JOB_IDS + "(?,?,?)}";
		int sqlErrCode=0;
		String sqlMessage=null;
		
		try {
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);		
			cstmt = conn.prepareCall(sqlString);
			cstmt.registerOutParameter(1, OracleTypes.CURSOR);
			cstmt.registerOutParameter(2, OracleTypes.INTEGER); 
			cstmt.registerOutParameter(3, OracleTypes.VARCHAR);
			
			cstmt.execute();
				
			sqlErrCode = cstmt.getInt(2);//sql error code 
			sqlMessage = cstmt.getString(3);//sql message
			
			if ( sqlErrCode > 0 ) {
				log.error(
				"In Method: getJobIDS() - Sql Exception from stored Procedure - SQL ERR CODE: "
						+ sqlErrCode + " SQL ERR MSG: " +sqlMessage );
				throw new Exception(sqlMessage);				
			}else{
				log.debug("In Method: getJobIDS()- " + sqlMessage );
			} 
			
			rs = (ResultSet) cstmt.getObject(1);
			
			while (rs.next()) {
				buf.append(rs.getString("job_id") + ",");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("getJobIDS(): EXIT");
		}
		return buf;
	}
	
	private String getReportCurrentDateTimeAsString() {
		java.util.Date tmpDt = new java.util.Date();
		Timestamp dateTime = new Timestamp(tmpDt.getTime());
		SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyyMMdd");
		return formatter.format(dateTime);
	}
	
	private String runDateFormat(Date tmpDt) {
		Timestamp dateTime = new Timestamp(tmpDt.getTime());
		SimpleDateFormat formatter = new java.text.SimpleDateFormat("MM/dd/yyyy");
		return formatter.format(dateTime);
	}

	private String TimeFormat(Timestamp dateTime) {
		SimpleDateFormat formatter = new java.text.SimpleDateFormat("hh:mm:ss");
		return formatter.format(dateTime);
	}
	
	
	public HSSFWorkbook generateXLSDFErrorReport(HSSFWorkbook workbook) throws MailSendException {
		log.info("generateXLSDFErrorReport(): ENTER");
		Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		HSSFRow row = null;
		String feed_id = null;
		String feed_date = null;
		String error_type = null;
		String error_record = null;
		String error_msg = null;		
		String sqlString = "{call "+ DataFeedReportConstants.QUERY_DF_ERROR_XLS_REPORT + "(?,?,?)}";
		int sqlErrCode=0;
		String sqlMessage=null;
		String dataCentre =  PropertyMgr.getInstance().getStringProperty(DataFeedReportConstants.DATA_CENTRE); // Based on dataCentre the procedures are to be executed either US/EU		
		try {
			if(dataCentre!=null && dataCentre.equalsIgnoreCase("EU") ){
				 sqlString = "{call "+ DataFeedReportConstants.QUERY_EU_DF_ERROR_XLS_REPORT + "(?,?,?)}";
				 log.info("Calling EU_DF_STATISTICS_REPORT: "+sqlString);				 
			}
			conn=DBConnectionMgr.getInstance().getOracleDBConnection(BRDBNames.PECOM);
			cstmt = conn.prepareCall(sqlString);
			cstmt.registerOutParameter(1, OracleTypes.CURSOR);
			cstmt.registerOutParameter(2, OracleTypes.INTEGER); 
			cstmt.registerOutParameter(3, OracleTypes.VARCHAR);
			
			cstmt.execute();
				
			sqlErrCode = cstmt.getInt(2);//sql error code 
			sqlMessage = cstmt.getString(3);//sql message
			
			if ( sqlErrCode > 0 ) {
				log.error(
				"In Method: generateXLSDFErrorReport() - Sql Exception from stored Procedure - SQL ERR CODE: "
						+ sqlErrCode + " SQL ERR MSG: " +sqlMessage );
				throw new Exception(sqlMessage);				
			}else{
				log.debug("In Method: generateXLSDFErrorReport()- " + sqlMessage );
			} 
			
			rs = (ResultSet) cstmt.getObject(1);

			
			HSSFSheet errorrptsheet = workbook.createSheet("DF Error Report");
			HSSFCellStyle style = workbook.createCellStyle();
			HSSFCellStyle style1 = workbook.createCellStyle();

			HSSFFont font = workbook.createFont();
			font.setFontName(HSSFFont.FONT_ARIAL);
			font.setFontHeightInPoints((short) 10);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font.setColor(HSSFColor.WHITE.index);
			style.setFont(font);

			style.setAlignment(HSSFCellStyle.ALIGN_JUSTIFY);
			style.setFillBackgroundColor(HSSFColor.AQUA.index);
			style.setFillPattern(HSSFCellStyle.BIG_SPOTS);
			style.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			style.setBorderBottom(HSSFCellStyle.BORDER_THICK);
			style.setBorderLeft(HSSFCellStyle.BORDER_THICK);
			style.setBorderRight(HSSFCellStyle.BORDER_THICK);
			style.setBorderTop(HSSFCellStyle.BORDER_THICK);

			style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style1.setBorderTop(HSSFCellStyle.BORDER_THIN);

			HSSFRow headerRow = errorrptsheet.createRow((short) 0);
			
			headerRow.createCell(0).setCellValue(new HSSFRichTextString("Feed ID"));
			headerRow.createCell(1).setCellValue(new HSSFRichTextString("Feed Date"));
			headerRow.createCell(2).setCellValue(new HSSFRichTextString("Error Type"));
			headerRow.createCell(3).setCellValue(new HSSFRichTextString("Error Record"));
			headerRow.createCell(4).setCellValue(new HSSFRichTextString("Error Message"));

			
			(headerRow.getCell(0)).setCellStyle(style);
			(headerRow.getCell(1)).setCellStyle(style);
			(headerRow.getCell(2)).setCellStyle(style);
			(headerRow.getCell(3)).setCellStyle(style);
			(headerRow.getCell(4)).setCellStyle(style);


			while (rs.next()) {
				row = errorrptsheet.createRow((short) (rs.getRow()));
					feed_id 		= rs.getString("feed_id");
					feed_date 		= runDateFormat(rs.getTimestamp("feed_date"));
					error_type 		= rs.getString("error_type");
					error_record	= rs.getString("error_record");
					error_msg  		= rs.getString("error_message");

				row.createCell(0).setCellValue(new HSSFRichTextString(feed_id));
				row.createCell(1).setCellValue(new HSSFRichTextString(feed_date));
				row.createCell(2).setCellValue(new HSSFRichTextString(error_type));
				row.createCell(3).setCellValue(new HSSFRichTextString(error_record));
				row.createCell(4).setCellValue(new HSSFRichTextString(error_msg));

				(row.getCell(0)).setCellStyle(style1);
				(row.getCell(1)).setCellStyle(style1);
				(row.getCell(2)).setCellStyle(style1);
				(row.getCell(3)).setCellStyle(style1);
				(row.getCell(4)).setCellStyle(style1);
			}
		} catch (SQLException e) {
			log.error("SQLException occurred in stored procedure call " +
					sqlString+e.getMessage());
			throw new MailSendException(e.getMessage());
		}catch (Exception ex){
			log.error("Exception occurred while preparing report attachment"+ex.getMessage());
			throw new MailSendException(ex.getMessage());
		} finally {			
			DBConnectionMgr.getInstance().closeDBObjects(conn, cstmt, rs);
			log.info("generateXLSDFErrorReport(): EXIT");
		}
		return workbook;
	}	
	
}
