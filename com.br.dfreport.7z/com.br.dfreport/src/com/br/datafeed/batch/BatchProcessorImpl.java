package com.br.datafeed.batch;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.adp.core.exception.ADPFatalException;
import com.adp.core.exception.ADPWarningException;
import com.br.batch.util.BatchUtil;
import com.br.batch.util.logger.BRLoggerFactory;
import com.br.batch.util.logger.IBRLogger;
import com.br.batch.util.logger.LogConfigFormat;

public class BatchProcessorImpl {
		
	public static IBRLogger	logger	= null;
	
	public List<String> parseApplications(String apps){
		logger.info("Entering Application BatchProcessorImpl::parseApplications");
		
		StringTokenizer Tokenizer  = null;
		List<String> appsList = new ArrayList<String>();
        String sApps = null;
        
		try{

			Tokenizer = new StringTokenizer(apps,",");
			while(Tokenizer.hasMoreTokens()){
				sApps =  Tokenizer.nextToken();
				appsList.add(sApps);
				logger.debug("Applications ==> " + sApps);
			}			
		}catch(Exception e){
			logger.error("ERROR BatchProcessorImpl::parseApplications " + e.toString());
		}
		
		logger.info("Exiting Application BatchProcessorImpl::parseApplications");
		return appsList;
	}
	
	private List<String> parseApplications(String[] args) throws Exception {
		logger.info("Entering Application BatchProcessorImpl::parseApplications");
		
		List<String> appsList = new ArrayList<String>();
        String sApps = null;
        
		try{
			
			for (int index = 0; index < args.length; index++ ){			
				sApps =  args[index];
				appsList.add(sApps);
				logger.debug("Applications ==> " + sApps);
			}			
		}catch(Exception e){
			logger.error("ERROR BatchProcessorImpl::parseApplications " + e.toString());
			throw e;
		}
		
		logger.info("Exiting Application BatchProcessorImpl::parseApplications");
		return appsList;
	}
	
	/**
	 * @param args
	 */
	public static void main(String args[]){
   	 	
		BatchUtil.initializeBatch(LogConfigFormat.PROPERTY);
		logger = BRLoggerFactory.getLogger(BatchProcessorImpl.class);
		
    	logger.info("Entering Application BatchProcessorImpl");
    	
    	List<String> appsList = new ArrayList<String>();
    	Iterator<String> iter = null;
    	String batchApp = null;
    	
     	try{     		
     		BatchProcessorImpl batchProcessor = new BatchProcessorImpl();
     		
     		appsList = batchProcessor.parseApplications(args);   		
     		
     		iter = appsList.iterator();
     		while (iter.hasNext()){  
     			batchApp = (String)iter.next();
     			
     			Class<?> apps = Class.forName(batchApp);
     			BatchProcessor batchProcessorImpl = (BatchProcessor)apps.newInstance();
     			batchProcessorImpl.executeBatch();
     		}
     	}catch(ADPWarningException ex){
			if(logger != null) {
				logger.error("Warning Error occured during BatchProcessorImpl Report Generation process", ex);
			}
			
			System.exit(1);
		}catch(ADPFatalException ex){
			if(logger != null) {
				logger.error("Fatal Error occured during BatchProcessorImpl Report Generation process", ex);
			}
			
			System.exit(2);
		}catch(ClassNotFoundException ex){
			if(logger != null) {
				logger.error("Fatal Error occured during BatchProcessorImpl Report Generation process", ex);
			}
			
			System.exit(2);
		}catch(IllegalAccessException il){
			if(logger != null) {
				logger.error("Fatal Error occured during BatchProcessorImpl Report Generation process", il);
			}
			
			System.exit(2);
		}catch(InstantiationException ins){
			if(logger != null) {
				logger.error("Fatal Error occured during BatchProcessorImpl Report Generation process", ins);
			}
			
			System.exit(2);
		}catch (Exception e){
			if(logger != null) {
				logger.error("BatchProcessorImpl::Exception", e);
			}
			
			System.exit(1);
		}	
     	
     	logger.info("Exiting Application BatchProcessorImpl");
     	
      }	

}
