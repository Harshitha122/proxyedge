package com.br.datafeed.batch;

import com.adp.core.exception.ADPFatalException;
import com.adp.core.exception.ADPWarningException;

public interface BatchProcessor {

	public void executeBatch() throws ADPWarningException, ADPFatalException;
	
}
